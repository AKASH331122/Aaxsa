package com.example.data.parser

import com.example.data.model.IptvChannel
import java.io.BufferedReader
import java.io.StringReader

object M3uParser {
    fun parse(m3uContent: String, playlistId: Long): List<IptvChannel> {
        val channels = mutableListOf<IptvChannel>()
        val reader = BufferedReader(StringReader(m3uContent))
        var line: String? = reader.readLine()
        
        var currentName = ""
        var currentLogo = ""
        var currentCategory = "General"
        var channelCount = 1

        while (line != null) {
            val trimmedLine = line.trim()
            if (trimmedLine.startsWith("#EXTINF:")) {
                currentName = ""
                currentLogo = ""
                currentCategory = "General"

                // Extract group-title
                val groupMatcher = "group-title=\"([^\"]+)\"".toRegex().find(trimmedLine)
                if (groupMatcher != null) {
                    currentCategory = groupMatcher.groupValues[1]
                } else {
                    val groupAltMatcher = "group-title=([^ ,\\n]+)".toRegex().find(trimmedLine)
                    if (groupAltMatcher != null) {
                        currentCategory = groupAltMatcher.groupValues[1].replace("\"", "")
                    }
                }

                // Extract tvg-logo
                val logoMatcher = "tvg-logo=\"([^\"]+)\"".toRegex().find(trimmedLine)
                if (logoMatcher != null) {
                    currentLogo = logoMatcher.groupValues[1]
                } else {
                    val logoAltMatcher = "logo=\"([^\"]+)\"".toRegex().find(trimmedLine)
                    if (logoAltMatcher != null) {
                        currentLogo = logoAltMatcher.groupValues[1]
                    }
                }

                // Extract channel name (last element of string after comma)
                val commaIndex = trimmedLine.lastIndexOf(',')
                if (commaIndex != -1 && commaIndex < trimmedLine.length - 1) {
                    currentName = trimmedLine.substring(commaIndex + 1).trim()
                }
            } else if (trimmedLine.isNotEmpty() && !trimmedLine.startsWith("#")) {
                val name = if (currentName.isNotEmpty()) currentName else "চ্যানেল $channelCount"
                channels.add(
                    IptvChannel(
                        playlistId = playlistId,
                        name = name,
                        streamUrl = trimmedLine,
                        logoUrl = if (currentLogo.isNotEmpty()) currentLogo else null,
                        category = if (currentCategory.isNotEmpty()) currentCategory else "অন্যান্য",
                        channelNumber = channelCount++
                    )
                )
                currentName = ""
                currentLogo = ""
                currentCategory = "General"
            }
            line = reader.readLine()
        }
        return channels
    }
}
