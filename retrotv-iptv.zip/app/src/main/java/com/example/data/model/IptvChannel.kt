package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "iptv_channels")
data class IptvChannel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long, // 0 indicates the default preloaded system channel list
    val name: String,
    val streamUrl: String,
    val logoUrl: String? = null,
    val category: String = "General",
    val isFavorite: Boolean = false,
    val channelNumber: Int = 0
)
