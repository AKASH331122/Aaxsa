package com.example.data.repository

import com.example.data.local.IptvDao
import com.example.data.model.IptvChannel
import com.example.data.model.Playlist
import com.example.data.parser.DefaultChannels
import com.example.data.parser.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class IptvRepository(private val iptvDao: IptvDao) {
    val allPlaylists: Flow<List<Playlist>> = iptvDao.getAllPlaylists()
    val allChannels: Flow<List<IptvChannel>> = iptvDao.getAllChannels()
    val favoriteChannels: Flow<List<IptvChannel>> = iptvDao.getFavoriteChannels()

    suspend fun preloadDefaultChannels() {
        withContext(Dispatchers.IO) {
            val existing = iptvDao.getChannelsByPlaylist(0)
            if (existing.isEmpty()) {
                val defaults = DefaultChannels.getDefaultChannels()
                iptvDao.insertChannels(defaults)
            }
        }
    }

    suspend fun addPlaylist(name: String, url: String): Result<Playlist> = withContext(Dispatchers.IO) {
        try {
            val playlist = Playlist(name = name, url = url)
            
            // 1. Fetch from internet first to ensure it's valid
            val m3uContent = fetchUrlContent(url)
            
            // 2. Insert playlist in DB
            val playlistId = iptvDao.insertPlaylist(playlist)
            val savedPlaylist = playlist.copy(id = playlistId)

            // 3. Parse channels and insert them
            val parsedChannels = M3uParser.parse(m3uContent, playlistId)
            
            if (parsedChannels.isNotEmpty()) {
                iptvDao.insertChannels(parsedChannels)
                Result.success(savedPlaylist)
            } else {
                iptvDao.deletePlaylistById(playlistId)
                Result.failure(Exception("কোনো চ্যানেল পাওয়া যায়নি! সঠিক M3U লিঙ্ক দিন।"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        iptvDao.deleteChannelsByPlaylist(playlistId)
        iptvDao.deletePlaylistById(playlistId)
    }

    suspend fun toggleFavorite(channel: IptvChannel) = withContext(Dispatchers.IO) {
        iptvDao.updateChannel(channel.copy(isFavorite = !channel.isFavorite))
    }

    private fun fetchUrlContent(urlString: String): String {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        connection.connectTimeout = 8000
        connection.readTimeout = 8000
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) RetroTV-IPTV-Player")
        
        connection.inputStream.bufferedReader().use {
            return it.readText()
        }
    }
}
