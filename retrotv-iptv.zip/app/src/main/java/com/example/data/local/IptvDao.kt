package com.example.data.local

import androidx.room.*
import com.example.data.model.IptvChannel
import com.example.data.model.Playlist
import kotlinx.coroutines.flow.Flow

@Dao
interface IptvDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<Playlist>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: Playlist): Long

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: Long)

    @Query("SELECT * FROM iptv_channels ORDER BY channelNumber ASC, name ASC")
    fun getAllChannels(): Flow<List<IptvChannel>>

    @Query("SELECT * FROM iptv_channels WHERE playlistId = :playlistId")
    suspend fun getChannelsByPlaylist(playlistId: Long): List<IptvChannel>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<IptvChannel>)

    @Query("DELETE FROM iptv_channels WHERE playlistId = :playlistId")
    suspend fun deleteChannelsByPlaylist(playlistId: Long)

    @Update
    suspend fun updateChannel(channel: IptvChannel)

    @Query("SELECT * FROM iptv_channels WHERE isFavorite = 1")
    fun getFavoriteChannels(): Flow<List<IptvChannel>>
}
