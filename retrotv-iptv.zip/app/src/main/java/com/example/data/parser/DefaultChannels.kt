package com.example.data.parser

import com.example.data.model.IptvChannel

object DefaultChannels {
    private val M3U_PRELOAD = """
        #EXTM3U
        #EXTINF:-1 tvg-logo="https://raw.githubusercontent.com/arshubham/IPTV-Logo/master/Somoy_TV.png" group-title="Bangla News",Somoy TV
        https://stream.somoynews.tv/hls/somoy.m3u8
        #EXTINF:-1 tvg-logo="https://raw.githubusercontent.com/arshubham/IPTV-Logo/master/BTV.png" group-title="Government",BTV World
        http://103.111.12.222:8000/live/btvworld/playlist.m3u8
        #EXTINF:-1 tvg-logo="https://raw.githubusercontent.com/arshubham/IPTV-Logo/master/Independent_TV.png" group-title="Bangla News",Independent TV
        https://unlimitedplay.top/live/independenttv.m3u8
        #EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/8/80/Al_Jazeera_English_logo.svg" group-title="Global News",Al Jazeera English
        https://live-hls-web-aje.getaj.net/AJE/index.m3u8
        #EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/e/e0/France24_en_logo.svg" group-title="Global News",France 24 English
        https://static.france24.com/live/F24_EN_LO_HLS/live_tv.m3u8
        #EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/d/df/NHK_World_logo.png" group-title="Global News",NHK World Japan
        https://nhkworld.akamaized.net/hls/live/2007395/nhkworld_eng/index.m3u8
        #EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/e/e2/DW_Logo_2012.svg" group-title="Global News",Deutsche Welle English
        https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/dwstream102_md.m3u8
        #EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/0/07/NASA_logo-keyline_full.svg" group-title="Science",NASA Select Live
        https://ntv1.nasatv.live/nasatv/ngrp:nasatv_all/playlist.m3u8
        #EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/4/41/Red_Bull_Logo.svg" group-title="Sports & Adventure",Red Bull TV
        https://rbmn-live.akamaized.net/hls/live/2003834/sports/master.m3u8
    """.trimIndent()

    fun getDefaultChannels(): List<IptvChannel> {
        return M3uParser.parse(M3U_PRELOAD, 0)
    }
}
