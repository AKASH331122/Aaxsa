package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import java.util.Random

@Composable
fun CrtOverlay(
    isSwitching: Boolean,
    modifier: Modifier = Modifier,
    onTransitionComplete: () -> Unit = {}
) {
    if (!isSwitching) return

    val animProgress = remember { Animatable(0f) }
    val random = remember { Random() }

    // Run custom CRT transition whenever isSwitching is set to true
    LaunchedEffect(isSwitching) {
        if (isSwitching) {
            animProgress.snapTo(0f)
            // Faster transitions give an authentic TV, snappier "jump" feeling! 450ms is perfect
            animProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 400, easing = LinearEasing)
            )
            onTransitionComplete()
        }
    }

    val progress = animProgress.value

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Define a nice CRT curved screen frame to mask outer portions (gives accurate old tube television feel)
        val path = Path().apply {
            val margin = 4f
            moveTo(margin, margin)
            quadraticTo(width / 2f, -10f, width - margin, margin)
            quadraticTo(width + 10f, height / 2f, width - margin, height - margin)
            quadraticTo(width / 2f, height + 10f, margin, height - margin)
            quadraticTo(-10f, height / 2f, margin, margin)
            close()
        }

        clipPath(path) {
            // Background fill
            drawRect(color = Color.Black)

            if (progress < 0.35f) {
                // Phase 1: Screen collapses vertically until it forms a thin glowing line
                val collapseRatio = (1f - (progress / 0.35f)).coerceIn(0.01f, 1f)
                val rectHeight = height * collapseRatio
                val top = (height - rectHeight) / 2f

                // Draw shrinking screen container filled with noise/static
                drawRect(
                    color = Color.DarkGray,
                    topLeft = Offset(0f, top),
                    size = Size(width, rectHeight)
                )

                // Fill the shrinking rectangle with CRT signal interference noise
                val noiseLineCount = 30
                for (i in 0 until noiseLineCount) {
                    val lineY = top + random.nextFloat() * rectHeight
                    val lineWidth = width * (0.4f + random.nextFloat() * 0.6f)
                    val lineX = random.nextFloat() * (width - lineWidth)
                    val r = random.nextInt(256)
                    val lineAlpha = 0.3f + random.nextFloat() * 0.5f
                    
                    drawRect(
                        color = Color(r, r, r).copy(alpha = lineAlpha),
                        topLeft = Offset(lineX, lineY),
                        size = Size(lineWidth, 3f * (1f + random.nextFloat() * 2f))
                    )
                }

                // Phosphor glowing top and bottom border bands
                drawRect(
                    color = Color.White.copy(alpha = 0.8f),
                    topLeft = Offset(0f, top),
                    size = Size(width, 4f)
                )
                drawRect(
                    color = Color.White.copy(alpha = 0.8f),
                    topLeft = Offset(0f, top + rectHeight - 4f),
                    size = Size(width, 4f)
                )

            } else if (progress >= 0.35f && progress <= 0.60f) {
                // Phase 2: Complete white/gray high-voltage static 'Jump' state with scanline flickering
                // Fill full screen with flickering analog television noise (highly realistic CRT cathode flicker)
                val squareSize = 6f
                val rows = (height / squareSize).toInt()
                val cols = (width / squareSize).toInt()

                // Optimization: Instead of drawing thousands of points, draw ~120 varying random strips & lines
                for (s in 0..120) {
                    val rx = random.nextFloat() * width
                    val ry = random.nextFloat() * height
                    val rW = 10f + random.nextFloat() * (width / 3f)
                    val rH = 2f + random.nextFloat() * 8f
                    val grayColor = random.nextInt(220) + 35
                    val alpha = 0.4f + random.nextFloat() * 0.6f
                    drawRect(
                        color = Color(grayColor, grayColor, grayColor).copy(alpha = alpha),
                        topLeft = Offset(rx, ry),
                        size = Size(rW, rH)
                    )
                }

                // Add scanlines moving across the screen
                val scanlineSpacing = 16f
                val scanlineOffset = (progress * 150f) % scanlineSpacing
                var y = scanlineOffset
                while (y < height) {
                    drawRect(
                        color = Color.Black.copy(alpha = 0.45f),
                        topLeft = Offset(0f, y),
                        size = Size(width, 3f)
                    )
                    y += scanlineSpacing
                }

                // Horizontal rolling interference bars
                val rollY = (progress * 3.5f * height) % height
                drawRect(
                    color = Color.White.copy(alpha = 0.15f),
                    topLeft = Offset(0f, rollY),
                    size = Size(width, 60f)
                )

                // Intense phosphor burn white line of collapsed beam in the center
                if (progress in 0.42f..0.52f) {
                    val lineWidth = width * (1f - (progress - 0.42f) / 0.1f * 0.9f).coerceIn(0.05f, 1f)
                    val lineX = (width - lineWidth) / 2f
                    drawRect(
                        color = Color.White,
                        topLeft = Offset(lineX, height / 2f - 2f),
                        size = Size(lineWidth, 4f)
                    )
                    // Faint circular neon glow
                    drawCircle(
                        color = Color(0xFFD6F5FF).copy(alpha = 0.6f),
                        radius = 20f * (1f - (progress - 0.42f) / 0.1f),
                        center = Offset(width / 2f, height / 2f)
                    )
                }

            } else {
                // Phase 3: Screen expands back vertically from collapsed line to full view (reveals new channel)
                val expandRatio = ((progress - 0.60f) / 0.40f).coerceIn(0f, 1f)
                val rectHeight = height * expandRatio
                val top = (height - rectHeight) / 2f

                // Draw background showing the channel static fading out
                drawRect(
                    color = Color.DarkGray.copy(alpha = 1f - expandRatio),
                    topLeft = Offset(0f, top),
                    size = Size(width, rectHeight)
                )

                // Fading scanline mesh on expanding viewport
                val spacing = 20f
                var yCoord = top
                while (yCoord < top + rectHeight) {
                    drawRect(
                        color = Color.Black.copy(alpha = 0.3f * (1f - expandRatio)),
                        topLeft = Offset(0f, yCoord),
                        size = Size(width, 2f)
                    )
                    yCoord += spacing
                }

                // Phosphor glowing green-cyan edges
                drawRect(
                    color = Color(0xFF88FFD6).copy(alpha = 0.6f * (1f - expandRatio)),
                    topLeft = Offset(0f, top),
                    size = Size(width, 3f)
                )
                drawRect(
                    color = Color(0xFF88FFD6).copy(alpha = 0.6f * (1f - expandRatio)),
                    topLeft = Offset(0f, top + rectHeight - 3f),
                    size = Size(width, 3f)
                )
            }

            // Draw nostalgic high-contrast CRT glass grid overlay on top of everything
            for (i in 0 until (width / 5).toInt()) {
                val gridX = i * 5f
                drawRect(
                    color = Color.White.copy(alpha = 0.03f),
                    topLeft = Offset(gridX, 0f),
                    size = Size(1f, height)
                )
            }
        }
    }
}
