package com.example.ui.screens

import android.view.KeyEvent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.IptvChannel
import com.example.data.model.Playlist
import com.example.ui.components.CrtOverlay
import com.example.ui.player.VideoPlayer
import com.example.ui.viewmodel.IptvViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Color Palette - Retro CRT Slate Theme
val MidnightBlack = Color(0xFF030508)
val DarkChassis = Color(0xFF0E121B)
val GlassCard = Color(0xFF161B26)
val PhosphorGreen = Color(0xFF22C55E) // Bright terminal green
val PhosphorAmber = Color(0xFFF59E0B) // Amber neon glow
val WhiteGlow = Color(0xFFE2E8F0)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTvScreen(
    viewModel: IptvViewModel,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    
    // ViewModel state bindings
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val channels by viewModel.filteredChannels.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val currentChannel by viewModel.currentChannel.collectAsStateWithLifecycle()
    val isCrtSwitching by viewModel.isCrtSwitching.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchTerm by viewModel.searchTerm.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val errorString by viewModel.errorString.collectAsStateWithLifecycle()

    var isFullScreen by remember { mutableStateOf(false) }
    var showAddPlaylistDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showInfoOverlay by remember { mutableStateOf(false) }

    // Remote D-pad channel HUD timer
    LaunchedEffect(currentChannel) {
        if (currentChannel != null) {
            showInfoOverlay = true
            delay(4000)
            showInfoOverlay = false
        }
    }

    // Capture TV remote keys (Channel up/down, center, back)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .onKeyEvent { keyEvent ->
                val isDown = keyEvent.nativeKeyEvent.action == KeyEvent.ACTION_DOWN
                if (isDown) {
                    when (keyEvent.nativeKeyEvent.keyCode) {
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            if (isFullScreen) {
                                viewModel.prevChannel()
                                true
                            } else false
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (isFullScreen) {
                                viewModel.nextChannel()
                                true
                            } else false
                        }
                        KeyEvent.KEYCODE_CHANNEL_UP -> {
                            viewModel.nextChannel()
                            true
                        }
                        KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                            viewModel.prevChannel()
                            true
                        }
                        KeyEvent.KEYCODE_BACK -> {
                            if (isFullScreen) {
                                isFullScreen = false
                                true
                            } else false
                        }
                        else -> false
                    }
                } else false
            }
    ) {
        // Landscape Full-Width Column: Header + Player HUD + Flat Channel Selector
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            
            // 1. Top Header Branded Navigation & Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Styled Retro Brand Indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(PhosphorGreen.copy(0.15f), RoundedCornerShape(8.dp))
                            .border(1.5.dp, PhosphorGreen, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = "Logo",
                            tint = PhosphorGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "RETRO TV",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "INTERACTIVE IPTV PLAYER",
                            color = PhosphorGreen,
                            fontSize = 7.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Middle: Filter Chips (All Channels vs Favorite Channels Only) & Search box
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // All Channels Tab Chip
                    var allFocused by remember { mutableStateOf(false) }
                    val isAllSelected = selectedCategory == "সব চ্যানেল"
                    Box(
                        modifier = Modifier
                            .onFocusChanged { allFocused = it.isFocused }
                            .graphicsLayer {
                                scaleX = if (allFocused) 1.05f else 1.0f
                                scaleY = if (allFocused) 1.05f else 1.0f
                            }
                            .clip(RoundedCornerShape(30.dp))
                            .background(
                                when {
                                    allFocused -> PhosphorGreen.copy(alpha = 0.2f)
                                    isAllSelected -> Color.White.copy(alpha = 0.08f)
                                    else -> Color.Transparent
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = if (allFocused || isAllSelected) PhosphorGreen else Color.Gray.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(30.dp)
                            )
                            .clickable { viewModel.selectCategory("সব চ্যানেল") }
                            .focusable()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.List, contentDescription = "", tint = PhosphorGreen, modifier = Modifier.size(14.dp))
                            Text("সকল চ্যানেল", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Favorites Tab Chip
                    var favFocused by remember { mutableStateOf(false) }
                    val isFavSelected = selectedCategory == "প্রিয় চ্যানেল"
                    Box(
                        modifier = Modifier
                            .onFocusChanged { favFocused = it.isFocused }
                            .graphicsLayer {
                                scaleX = if (favFocused) 1.05f else 1.0f
                                scaleY = if (favFocused) 1.05f else 1.0f
                            }
                            .clip(RoundedCornerShape(30.dp))
                            .background(
                                when {
                                    favFocused -> PhosphorGreen.copy(alpha = 0.2f)
                                    isFavSelected -> Color.White.copy(alpha = 0.08f)
                                    else -> Color.Transparent
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = if (favFocused || isFavSelected) PhosphorGreen else Color.Gray.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(30.dp)
                            )
                            .clickable { viewModel.selectCategory("প্রিয় চ্যানেল") }
                            .focusable()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Favorite, contentDescription = "", tint = Color.Red, modifier = Modifier.size(14.dp))
                            Text("প্রিয় চ্যানেল", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Modern Terminal Search Input
                    OutlinedTextField(
                        value = searchTerm,
                        onValueChange = { viewModel.setSearchTerm(it) },
                        placeholder = { Text("চ্যানেল খুঁজুন...", fontSize = 11.sp, color = Color.Gray) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PhosphorGreen,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                            focusedLabelColor = PhosphorGreen,
                            unfocusedLabelColor = Color.Gray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .width(180.dp)
                            .height(38.dp)
                            .padding(0.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, color = Color.White)
                    )
                }

                // Right: Playlists Quick Action Managers
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    var focusAdd by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .onFocusChanged { focusAdd = it.isFocused }
                            .graphicsLayer {
                                scaleX = if (focusAdd) 1.05f else 1.0f
                                scaleY = if (focusAdd) 1.05f else 1.0f
                            }
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (focusAdd) PhosphorAmber.copy(0.15f) else Color.Transparent)
                            .border(
                                1.dp,
                                if (focusAdd) PhosphorAmber else Color.White.copy(0.08f),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { showAddPlaylistDialog = true }
                            .focusable()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = PhosphorAmber, modifier = Modifier.size(14.dp))
                            Text("প্লেলিস্ট যোগ", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    var focusDel by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .onFocusChanged { focusDel = it.isFocused }
                            .graphicsLayer {
                                scaleX = if (focusDel) 1.05f else 1.0f
                                scaleY = if (focusDel) 1.05f else 1.0f
                            }
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (focusDel) Color.Red.copy(0.15f) else Color.Transparent)
                            .border(
                                1.dp,
                                if (focusDel) Color.Red else Color.White.copy(0.08f),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { showDeleteDialog = true }
                            .focusable()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(14.dp))
                            Text("প্লেলিস্ট মুছুন", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 2. Middle Row: Retro TV Cabinet Player (16:9) + HUD Details
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.2f),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // The Retro Cabinet Housing (Displays exoplayer within real glass tube bezel)
                Box(
                    modifier = Modifier
                        .weight(1.5f)
                        .fillMaxHeight()
                        .background(DarkChassis, RoundedCornerShape(16.dp))
                        .border(3.dp, Color(0xFF2C3241), RoundedCornerShape(16.dp))
                        .padding(12.dp)
                        .clickable {
                            if (currentChannel != null) {
                                isFullScreen = true
                            }
                        }
                ) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        
                        // Left Inner: The CRT Screen itself
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black)
                        ) {
                            if (currentChannel != null) {
                                VideoPlayer(
                                    streamUrl = currentChannel!!.streamUrl,
                                    modifier = Modifier.fillMaxSize(),
                                    onPlaybackStateChanged = { isPlaying, isLoading, errorMsg ->
                                        // Handle fast buffering alerts internally
                                    }
                                )
                            } else {
                                // Empty CRT Raster screen glow
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.radialGradient(
                                                colors = listOf(Color(0xFF1E293B), Color.Black),
                                                radius = 400f
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = "No Signal",
                                            tint = PhosphorGreen.copy(alpha = 0.5f),
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "কোনো সিগন্যাল নেই",
                                            color = PhosphorGreen.copy(alpha = 0.7f),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // CRT TV Transition flicker Layer
                            CrtOverlay(
                                isSwitching = isCrtSwitching,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        
                        // Right Inner: Nostalgic Cabinet Controllers (Dials, Speaker vents)
                        Column(
                            modifier = Modifier
                                .wrapContentWidth()
                                .fillMaxHeight()
                                .padding(start = 12.dp, end = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceEvenly
                        ) {
                            // Dynamic channel indicator number
                            Box(
                                modifier = Modifier
                                    .background(Color.Black, RoundedCornerShape(4.dp))
                                    .border(1.dp, PhosphorAmber.copy(0.4f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = currentChannel?.channelNumber?.toString()?.padStart(2, '0') ?: "--",
                                    color = PhosphorAmber,
                                    fontSize = 18.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Dial knobs
                            KnobSelector(label = "V-HOLD")
                            KnobSelector(label = "CH SELECT")

                            // Speaker vent line grills
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                repeat(6) {
                                    Box(
                                        modifier = Modifier
                                            .size(width = 36.dp, height = 3.dp)
                                            .background(Color.Black.copy(alpha = 0.6f))
                                    )
                                }
                            }
                        }
                    }
                }

                // Metadata HUD Info: Quick controls and channel description
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(GlassCard, RoundedCornerShape(12.dp))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "IPTV STREAM",
                                color = PhosphorAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            
                            if (currentChannel != null) {
                                IconButton(
                                    onClick = { viewModel.toggleFavorite(currentChannel!!) }
                                ) {
                                    Icon(
                                        imageVector = if (currentChannel!!.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Favorite",
                                        tint = if (currentChannel!!.isFavorite) Color.Red else Color.LightGray
                                    )
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentChannel?.name ?: "চ্যানেল নির্বাচন করুন",
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "IPTV m3u লিঙ্কটির সব চ্যানেল সরাসরি নিচে প্রদর্শিত হচ্ছে। ক্যাটাগরি ছাড়াই সহজ উপায়ে ইচ্ছামতো স্ক্রোল এবং সার্চ করুন।",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }

                    // Info Tips Guide
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(0.4f), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = "Manual",
                            tint = PhosphorGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "ডাবল ট্যাপ করে ফুল-স্ক্রিন করুন ও রিমোট দিয়ে চ্যানেল পরিবর্তন করুন!",
                            color = PhosphorGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Grid Row: Widescreen Flat Channels Grid Selector
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.3f)
            ) {
                if (channels.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "কোনো চ্যানেল পাওয়া যায়নি! প্লেলিস্ট লিঙ্ক যোগ করুন বা সার্চ পরিবর্তন করুন।",
                            color = Color.LightGray,
                            fontSize = 14.sp
                        )
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 130.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(channels) { channel ->
                            ChannelItemCard(
                                channel = channel,
                                isSelected = currentChannel?.name == channel.name,
                                onClick = { viewModel.selectChannel(channel) }
                            )
                        }
                    }
                }
            }
        }

        // FULL SCREEN LAYER Overlay (when maximized)
        AnimatedVisibility(
            visible = isFullScreen && currentChannel != null,
            enter = scaleIn(initialScale = 0.9f) + fadeIn(),
            exit = scaleOut(targetScale = 0.9f) + fadeOut()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (currentChannel != null) {
                    VideoPlayer(
                        streamUrl = currentChannel!!.streamUrl,
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable { showInfoOverlay = !showInfoOverlay },
                        onPlaybackStateChanged = { isPlaying, isLoading, errorMsg -> }
                    )
                }

                CrtOverlay(
                    isSwitching = isCrtSwitching,
                    modifier = Modifier.fillMaxSize()
                )

                // Back control on screen tap
                IconButton(
                    onClick = { isFullScreen = false },
                    modifier = Modifier
                        .padding(24.dp)
                        .align(Alignment.TopStart)
                        .background(Color.Black.copy(0.6f), RoundedCornerShape(30.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                // Nostalgic CRT Overlay Raster filter on full screen
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            val spacing = 8f
                            var y = 0f
                            while (y < size.height) {
                                drawRect(
                                    color = Color.Black.copy(alpha = 0.12f),
                                    topLeft = Offset(0f, y),
                                    size = Size(size.width, 2f)
                                )
                                y += spacing
                            }
                        }
                )

                // TV remote style heads-up channel display bar (shown momentarily)
                AnimatedVisibility(
                    visible = showInfoOverlay,
                    enter = slideInVertically { it } + fadeIn(),
                    exit = slideOutVertically { it } + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(0.9f))
                                )
                            )
                            .padding(horizontal = 48.dp, vertical = 32.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "SOURCE: M3U PLAYLIST",
                                color = PhosphorAmber,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(PhosphorGreen, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "CH ${currentChannel?.channelNumber ?: 0}",
                                        color = Color.Black,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = currentChannel?.name ?: "",
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        
                        Text(
                            text = "▲ ▼ বাটনে চ্যানেল পরিবর্তন | BACK চাপুন মেন্যুতে ফিরতে",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Loading and Add Playlist dialog modals
        if (isLoading) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GlassCard)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = PhosphorGreen)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "লিঙ্ক যাচাই করে চ্যানেল ক্যাশ করা হচ্ছে...",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        if (showAddPlaylistDialog) {
            AddPlaylistDialog(
                onDismiss = { showAddPlaylistDialog = false },
                onAdd = { name, url ->
                    viewModel.addPlaylist(name, url)
                    showAddPlaylistDialog = false
                }
            )
        }

        if (showDeleteDialog) {
            DeletePlaylistDialog(
                playlists = playlists.filter { it.isUserAdded },
                onDismiss = { showDeleteDialog = false },
                onDelete = {
                    viewModel.deletePlaylist(it.id, it.name)
                    showDeleteDialog = false
                }
            )
        }

        // Simple error dialogue
        if (errorString != null) {
            AlertDialog(
                onDismissRequest = { viewModel.clearError() },
                title = { Text(text = "প্লেলিস্ট এরর", color = PhosphorAmber) },
                text = { Text(text = errorString ?: "", color = Color.White) },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = PhosphorGreen),
                        onClick = { viewModel.clearError() }
                    ) {
                        Text("ঠিক আছে", color = Color.Black)
                    }
                },
                containerColor = GlassCard,
                textContentColor = Color.White
            )
        }
    }
}

@Composable
fun ChannelItemCard(
    channel: IptvChannel,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .onFocusChanged { isFocused = it.isFocused }
            .graphicsLayer {
                scaleX = if (isFocused) 1.05f else 1.0f
                scaleY = if (isFocused) 1.05f else 1.0f
            }
            .background(
                if (isFocused) PhosphorGreen.copy(0.08f) else GlassCard,
                RoundedCornerShape(10.dp)
            )
            .border(
                width = 2.dp,
                color = when {
                    isFocused -> PhosphorGreen
                    isSelected -> PhosphorGreen.copy(0.4f)
                    else -> Color.Transparent
                },
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .focusable()
            .padding(12.dp)
            .height(60.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // TV Channel static number bubble
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .background(Color.Black.copy(0.5f), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = channel.channelNumber.toString(),
                    color = if (isFocused) PhosphorGreen else Color.LightGray,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = channel.name,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "চ্যানেল নং ${channel.channelNumber}",
                    color = Color.Gray,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (channel.isFavorite) {
                Icon(
                    Icons.Default.Favorite,
                    contentDescription = "Favorite",
                    tint = Color.Red,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

@Composable
fun KnobSelector(label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(modifier = Modifier.size(24.dp)) {
            drawCircle(color = Color(0xFF1E293B))
            drawCircle(color = Color.Black, radius = 8.dp.toPx())
            // Notch marker
            drawLine(
                color = PhosphorAmber,
                start = center,
                end = Offset(center.x, center.y - 10.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = Color.Gray,
            fontSize = 7.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPlaylistDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, url: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GlassCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .width(440.dp)
                .wrapContentHeight()
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .background(DarkChassis)
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "নতুন M3U প্লেলিস্ট সংযোজন",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("প্লেলিস্টের নাম (যেমন: MyBD IPTV)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PhosphorGreen,
                        unfocusedBorderColor = Color.Gray,
                        focusedLabelColor = PhosphorGreen,
                        unfocusedLabelColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("M3U প্লেলিস্ট URL বা লিঙ্ক") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PhosphorGreen,
                        unfocusedBorderColor = Color.Gray,
                        focusedLabelColor = PhosphorGreen,
                        unfocusedLabelColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // TV-Friendly Fast loader templates to skip typing!
                Text(
                    text = "দ্রুত লোড করার জন্য ডেমো লিঙ্ক (ক্লিক করুন):",
                    color = PhosphorAmber,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                // Paste Bengali Free IPTV preset instantly
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    var isTemp1Focused by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isTemp1Focused = it.isFocused }
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isTemp1Focused) PhosphorGreen.copy(0.2f) else GlassCard)
                            .border(1.dp, if (isTemp1Focused) PhosphorGreen else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable {
                                name = "Global Free IPTV"
                                url = "https://iptv-org.github.io/iptv/countries/bd.m3u"
                            }
                            .focusable()
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🇧🇩 BD Streams M3U", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    var isTemp2Focused by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { isTemp2Focused = it.isFocused }
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isTemp2Focused) PhosphorGreen.copy(0.2f) else GlassCard)
                            .border(1.dp, if (isTemp2Focused) PhosphorGreen else Color.Transparent, RoundedCornerShape(6.dp))
                            .clickable {
                                name = "US News Pluto"
                                url = "https://raw.githubusercontent.com/FossTitan/Samsung-TV-Plus-M3u/main/SamsungTVPlus.m3u"
                            }
                            .focusable()
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📺 US Free TV M3U", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    var cancelFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { cancelFocused = it.isFocused }
                            .border(
                                width = 1.dp,
                                color = if (cancelFocused) Color.White else Color.Gray,
                                shape = RoundedCornerShape(20.dp)
                            )
                    ) {
                        Text("বাতিল", color = Color.White)
                    }

                    var addFocused by remember { mutableStateOf(false) }
                    Button(
                        onClick = {
                            if (name.isNotEmpty() && url.isNotEmpty()) {
                                onAdd(name, url)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = if (addFocused) PhosphorGreen else Color(0xFF1E3A1E)),
                        modifier = Modifier
                            .weight(1f)
                            .onFocusChanged { addFocused = it.isFocused }
                            .border(
                                width = 1.dp,
                                color = if (addFocused) Color.White else Color.Transparent,
                                shape = RoundedCornerShape(20.dp)
                            )
                    ) {
                        Text("লোড করুন", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun DeletePlaylistDialog(
    playlists: List<Playlist>,
    onDismiss: () -> Unit,
    onDelete: (Playlist) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GlassCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .width(360.dp)
                .wrapContentHeight()
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier
                    .background(DarkChassis)
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "প্লেলিস্ট অপসারণ",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black
                )

                if (playlists.isEmpty()) {
                    Text(
                        text = "আপনার নিজের যুক্ত করা কোনো প্লেলিস্ট নেই। ডিফল্ট প্লেলিস্ট মুছে ফেলা সম্ভব নয়।",
                        color = Color.LightGray,
                        fontSize = 13.sp
                    )
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("বন্ধ করুন", color = Color.White)
                    }
                } else {
                    Text(
                        text = "নিচে থেকে যে প্লেলিস্টটি মুছতে চান তা নির্বাচন করুন:",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.heightIn(max = 200.dp)
                    ) {
                        items(playlists) { playlist ->
                            var itemFocused by remember { mutableStateOf(false) }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { itemFocused = it.isFocused }
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (itemFocused) Color.Red.copy(0.15f) else GlassCard)
                                    .border(
                                        1.dp,
                                        if (itemFocused) Color.Red else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onDelete(playlist) }
                                    .focusable()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.List, contentDescription = "Folder", tint = PhosphorAmber, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(text = playlist.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray, modifier = Modifier.size(14.dp))
                            }
                        }
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("বন্ধ করুন", color = Color.White)
                    }
                }
            }
        }
    }
}
