package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.IptvDatabase
import com.example.data.model.IptvChannel
import com.example.data.model.Playlist
import com.example.data.repository.IptvRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class IptvViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: IptvRepository
    
    // Playlists and raw channel streams
    val playlists: StateFlow<List<Playlist>>
    val allChannels: StateFlow<List<IptvChannel>>
    val favoriteChannels: StateFlow<List<IptvChannel>>

    // Selected States
    private val _selectedCategory = MutableStateFlow("সব চ্যানেল")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchTerm = MutableStateFlow("")
    val searchTerm: StateFlow<String> = _searchTerm.asStateFlow()

    private val _currentChannel = MutableStateFlow<IptvChannel?>(null)
    val currentChannel: StateFlow<IptvChannel?> = _currentChannel.asStateFlow()

    // CRT screen trigger state
    private val _isCrtSwitching = MutableStateFlow(false)
    val isCrtSwitching: StateFlow<Boolean> = _isCrtSwitching.asStateFlow()

    // Loading & Errors
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorString = MutableStateFlow<String?>(null)
    val errorString: StateFlow<String?> = _errorString.asStateFlow()

    // Filtered lists shown in UI - flat structure with no arbitrary categories
    val categories: StateFlow<List<String>> = MutableStateFlow(listOf("সব চ্যানেল", "প্রিয় চ্যানেল")).asStateFlow()
    val filteredChannels: StateFlow<List<IptvChannel>>

    init {
        val iptvDao = IptvDatabase.getDatabase(application).iptvDao()
        repository = IptvRepository(iptvDao)

        playlists = repository.allPlaylists.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allChannels = repository.allChannels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        favoriteChannels = repository.favoriteChannels.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Feed filtered channel list depending on search query and category tab selection
        filteredChannels = combine(allChannels, favoriteChannels, _selectedCategory, _searchTerm) { channels, favorites, category, search ->
            var list = when (category) {
                "প্রিয় চ্যানেল" -> favorites
                else -> channels
            }
            if (search.isNotEmpty()) {
                list = list.filter { it.name.contains(search, ignoreCase = true) }
            }
            list
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Warm up defaults
        viewModelScope.launch {
            _isLoading.value = true
            repository.preloadDefaultChannels()
            
            // Auto play first channel on launch if available
            allChannels.filter { it.isNotEmpty() }.firstOrNull()?.let { list ->
                if (_currentChannel.value == null && list.isNotEmpty()) {
                    _currentChannel.value = list.first()
                }
            }
            _isLoading.value = false
        }
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSearchTerm(query: String) {
        _searchTerm.value = query
    }

    // Traditional CRT Channel selection sequence: Collapse -> Switch source -> Expand
    fun selectChannel(channel: IptvChannel) {
        viewModelScope.launch {
            if (_isCrtSwitching.value) return@launch // Prevent spamming
            _isCrtSwitching.value = true
            
            // Phase 1: Wait for screen to collapse to black-dot point (150ms)
            delay(150)
            
            // Swap stream URL at maximum visual television static density
            _currentChannel.value = channel
            
            // Phase 2: Fade static noise and expand screen back (250ms)
            delay(250)
            _isCrtSwitching.value = false
        }
    }

    // Simulate standard TV Remote up-down channel surfing
    fun nextChannel() {
        val channels = filteredChannels.value
        val active = currentChannel.value
        if (channels.isEmpty() || active == null) return

        val currentIndex = channels.indexOfFirst { it.name == active.name && it.streamUrl == active.streamUrl }
        val targetIndex = if (currentIndex != -1 && currentIndex < channels.size - 1) {
            currentIndex + 1
        } else {
            0 // Wrap around to first channel
        }
        selectChannel(channels[targetIndex])
    }

    fun prevChannel() {
        val channels = filteredChannels.value
        val active = currentChannel.value
        if (channels.isEmpty() || active == null) return

        val currentIndex = channels.indexOfFirst { it.name == active.name && it.streamUrl == active.streamUrl }
        val targetIndex = if (currentIndex > 0) {
            currentIndex - 1
        } else {
            channels.size - 1 // Wrap around to last channel
        }
        selectChannel(channels[targetIndex])
    }

    fun addPlaylist(name: String, url: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorString.value = null
            
            val result = repository.addPlaylist(name, url)
            if (result.isFailure) {
                _errorString.value = result.exceptionOrNull()?.message ?: "প্লেলিস্ট যুক্ত করতে ত্রুটি হয়েছে!"
            } else {
                // Return to main list
                _selectedCategory.value = "সব চ্যানেল"
                // Autoplay first channel of newly added playlist
                val newChannels = repository.allChannels.firstOrNull()?.filter { it.playlistId != 0L }
                if (!newChannels.isNullOrEmpty()) {
                    selectChannel(newChannels.first())
                }
            }
            _isLoading.value = false
        }
    }

    fun deletePlaylist(playlistId: Long, playlistName: String) {
        viewModelScope.launch {
            _isLoading.value = true
            repository.deletePlaylist(playlistId)
            
            // Revert search and category constraints
            _selectedCategory.value = "সব চ্যানেল"
            _isLoading.value = false
        }
    }

    fun toggleFavorite(channel: IptvChannel) {
        viewModelScope.launch {
            repository.toggleFavorite(channel)
            // Sync active channel state if changed
            if (_currentChannel.value?.id == channel.id) {
                _currentChannel.value = _currentChannel.value?.copy(isFavorite = !channel.isFavorite)
            }
        }
    }

    fun clearError() {
        _errorString.value = null
    }
}
