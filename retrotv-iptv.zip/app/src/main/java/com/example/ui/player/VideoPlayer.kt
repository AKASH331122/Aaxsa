package com.example.ui.player

import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayer(
    streamUrl: String,
    modifier: Modifier = Modifier,
    onPlaybackStateChanged: (isPlaying: Boolean, isLoading: Boolean, errorMsg: String?) -> Unit = { _, _, _ -> }
) {
    val context = LocalContext.current

    // Initialize player with fast-play optimization (low-latency load control)
    val exoPlayer = remember {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                1000, // minBufferMs
                3000, // maxBufferMs
                400,  // bufferForPlaybackMs (ultra-low duration for instant load without buffering lag)
                800   // bufferForPlaybackAfterRebufferMs
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .build()
            .apply {
                playWhenReady = true
                repeatMode = Player.REPEAT_MODE_OFF
            }
    }

    // Set up media source whenever the stream URL changes
    LaunchedEffect(streamUrl) {
        onPlaybackStateChanged(false, true, null)
        exoPlayer.stop()
        exoPlayer.clearMediaItems()

        try {
            val dataSourceFactory = DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) RetroTV-IPTV-Player")
                .setConnectTimeoutMs(5000)
                .setReadTimeoutMs(5000)
                .setAllowCrossProtocolRedirects(true)

            val mediaSource = if (streamUrl.contains(".m3u8") || streamUrl.contains("m3u8")) {
                HlsMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(streamUrl))
            } else {
                MediaItem.fromUri(streamUrl)
            }

            if (mediaSource is MediaItem) {
                exoPlayer.setMediaItem(mediaSource)
            } else {
                exoPlayer.setMediaSource(mediaSource as androidx.media3.exoplayer.source.MediaSource)
            }

            exoPlayer.prepare()
        } catch (e: Exception) {
            onPlaybackStateChanged(false, false, "প্লেব্যাক ত্রুটি: ${e.localizedMessage}")
        }
    }

    // Monitor playback state and errors
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val isPlaying = playbackState == Player.STATE_READY && exoPlayer.playWhenReady
                val isLoading = playbackState == Player.STATE_BUFFERING
                val error = if (playbackState == Player.STATE_IDLE && exoPlayer.playerError != null) {
                    "প্লেব্যাক ব্যর্থ হয়েছে। লিঙ্ক পরীক্ষা করুন।"
                } else null
                
                onPlaybackStateChanged(isPlaying, isLoading, error)
            }

            override fun onPlayerError(error: PlaybackException) {
                onPlaybackStateChanged(false, false, "প্লেব্যাক ব্যর্থ হয়েছে: " + (error.localizedMessage ?: "সংযোগ সমস্যা"))
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    // Layout representation in Compose
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false // Custom controller overlay is overlayed beautifully in Compose
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                player = exoPlayer
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        modifier = modifier
    )
}
